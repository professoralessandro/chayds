# pagseguro

Códigos necessários para implementar o checkout transparente do PagSeguro
